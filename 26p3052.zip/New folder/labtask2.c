#include<stdio.h>
int main()
{
	
   int pin;
   int attempts=0;
   
	do {
		
		printf(" enter the pin \n");
		scanf(" %d", &pin);
		attempts++;
		
		if (pin ==4321){
			printf("  access granted ");
		}
	
	 else if ( attempts< 3)
	
	{
		printf(" wrong password attempts left %d", 3 - attempts);
	}
	else {
	
	
 printf(" block the card plaese contact your bank");
   }
   
   
	}
	while (pin != 4321 && attempts< 3);
	

	return 0;
	
   }


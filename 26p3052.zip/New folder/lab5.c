
#include <stdio.h>

int main() {
    int choice, quantity;
    int totalItems = 0;
    float bill = 0, discount = 0, payable;
    
    do {
        printf("\n===== UNIVERSITY CANTEEN MENU =====\n");
        printf("1. Tea       - Rs 60\n");
        printf("2. Samosa    - Rs 40\n");
        printf("3. Sandwich  - Rs 180\n");
        printf("4. Checkout\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice >= 1 && choice <= 3) {
            printf("Enter quantity: ");
            scanf("%d", &quantity);

            if (quantity <= 0) {
                printf("Invalid quantity.\n");
            } else {
                totalItems += quantity;

                if (choice == 1) {
                    bill += 60 * quantity;
                } else if (choice == 2) {
                    bill += 40 * quantity;
                } else {
                    bill += 180 * quantity;
                }

                printf("Current bill: Rs %.2f\n", bill);
            }
        }
        else if (choice == 4) {
            printf("Proceeding to checkout...\n");
        }
        else {
            printf("Invalid choice. Try again.\n");
        }

    } while (choice != 4);

    if (bill > 1000) {
        discount = bill * 0.10;
    }

    payable = bill - discount;

    printf("\n===== FINAL BILL =====\n");
    printf("Total items ordered: %d\n", totalItems);
    printf("Bill: Rs %.2f\n", bill);
    printf("Discount: Rs %.2f\n", discount);
    printf("Amount payable: Rs %.2f\n", payable);

    return 0;
}

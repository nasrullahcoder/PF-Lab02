
#include <stdio.h>

int main() {
    int runs;
    int totalRuns = 0;
    int boundaries = 0;
    int dotBalls = 0;

    for (int ball = 1; ball <= 6; ball++) {
        printf("Enter runs for ball %d (0-6): ", ball);
        scanf("%d", &runs);

        totalRuns = totalRuns + runs;

        if (runs == 4 || runs == 6) {
            boundaries++;
        }

        if (runs == 0) {
            dotBalls++;
        }
    }

    printf("Total runs: %d\n", totalRuns);
    printf("Boundaries: %d\n", boundaries);
    printf("Dot balls: %d\n", dotBalls);

    return 0;
}

#include <stdio.h>
int main ()
{
	int n ,marks;;
     int pass = 0, failed =0;
     int highest=0 ;
     int total =0;
     float average;
     
     printf(" enter the number ");
     scanf(" %d", &n);
     for (  int i=1; i<= n; i++)
     {
     	printf(" enter marks of student");
     	scanf(" %d", &marks);
     	
     	total = total+ marks;
     	
     if (marks >=50){
     	
     	pass++;
	 }
	 
	 else
	 {
	 	failed++;
	 }
	 if (i==1 || marks>highest){
	 	highest= marks;
	 }
	 
	 
	 }
       // Explicit cast converts total to float before division.
    average = (float) total / n;

    printf("\nStudents passed: %d\n", pass);
    printf("Students failed: %d\n", failed);
    printf("Highest marks: %d\n", highest);
    printf("Class average: %.2f\n", average);

    return 0;
}
 
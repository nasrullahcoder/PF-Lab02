#include<stdio.h>
int main ()
{
	int laptopprice, savings, monthlysaving;
	int month=0;
	
	printf("enter the price of laptop: \n");
	scanf(" %d", &laptopprice);
	
	printf(" enter the current saving \n");
	scanf(" %d", &savings);
	
	printf(" enter her monthly saving \n");
	
	// The while loop runs only if savings are less than the laptop price.
    // If savings are already enough, the condition is false,
    // so the loop does not execute and months remains 0.
	
	
 	while (savings < laptopprice)
	{
		savings= savings+ monthlysaving;
		month++;
		printf("  total saving after month %d %d", month, savings);
		
	}
	 printf(" month needed %d", month);
	 
	 
	 return 0;
	 
	 }